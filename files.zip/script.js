/* ═══════════════════════════════════════════════════
   AMIT KUMAR MOHANTY — PORTFOLIO SCRIPT
   ═══════════════════════════════════════════════════ */

/* ─── LOADER ─── */
(function () {
  document.body.classList.add('loading');
  const loader   = document.getElementById('loader');
  const fill     = loader.querySelector('.loader-fill');
  const pct      = document.getElementById('loaderPct');
  let progress   = 0;
  const interval = setInterval(() => {
    progress += Math.random() * 18 + 4;
    if (progress >= 100) {
      progress = 100;
      clearInterval(interval);
      setTimeout(() => {
        loader.classList.add('hidden');
        document.body.classList.remove('loading');
        triggerHeroReveal();
      }, 300);
    }
    fill.style.width = progress + '%';
    pct.textContent  = Math.floor(progress) + '%';
  }, 80);
})();

/* ─── HERO REVEAL ─── */
function triggerHeroReveal() {
  const lines = document.querySelectorAll('.reveal-line');
  lines.forEach((el, i) => {
    setTimeout(() => {
      el.style.transition = `opacity 0.6s ease ${i * 0.1}s, transform 0.6s ease ${i * 0.1}s`;
      el.classList.add('in');
    }, i * 80);
  });
  const photo = document.querySelector('.reveal-photo');
  if (photo) photo.classList.add('in');
  startTyping();
}

/* ─── TYPING EFFECT ─── */
const titles = [
  'Senior QA Engineer',
  'Functional Tester',
  'TRIRIGA QA Specialist',
  'Agile QA Advocate',
];
let titleIdx = 0, charIdx = 0, isDeleting = false;
const typingEl = document.getElementById('typingText');

function startTyping() {
  if (!typingEl) return;
  typeLoop();
}

function typeLoop() {
  const current = titles[titleIdx];
  if (!isDeleting) {
    typingEl.textContent = current.slice(0, charIdx + 1);
    charIdx++;
    if (charIdx === current.length) {
      isDeleting = true;
      setTimeout(typeLoop, 1800);
      return;
    }
  } else {
    typingEl.textContent = current.slice(0, charIdx - 1);
    charIdx--;
    if (charIdx === 0) {
      isDeleting = false;
      titleIdx   = (titleIdx + 1) % titles.length;
    }
  }
  setTimeout(typeLoop, isDeleting ? 50 : 90);
}

/* ─── CUSTOM CURSOR ─── */
const cursor      = document.getElementById('cursor');
const cursorTrail = document.getElementById('cursorTrail');
let mouseX = -100, mouseY = -100;

document.addEventListener('mousemove', (e) => {
  mouseX = e.clientX;
  mouseY = e.clientY;
  if (cursor) {
    cursor.style.left = mouseX + 'px';
    cursor.style.top  = mouseY + 'px';
  }
  setTimeout(() => {
    if (cursorTrail) {
      cursorTrail.style.left = mouseX + 'px';
      cursorTrail.style.top  = mouseY + 'px';
    }
  }, 80);
});

document.addEventListener('mousedown', () => {
  if (cursor) { cursor.style.transform = 'translate(-50%,-50%) scale(0.7)'; }
});
document.addEventListener('mouseup', () => {
  if (cursor) { cursor.style.transform = 'translate(-50%,-50%) scale(1)'; }
});

document.querySelectorAll('a, button, input, textarea, .tool-badge').forEach((el) => {
  el.addEventListener('mouseenter', () => {
    if (cursor) { cursor.style.width = '20px'; cursor.style.height = '20px'; cursor.style.opacity = '0.7'; }
    if (cursorTrail) { cursorTrail.style.width = '48px'; cursorTrail.style.height = '48px'; }
  });
  el.addEventListener('mouseleave', () => {
    if (cursor) { cursor.style.width = '12px'; cursor.style.height = '12px'; cursor.style.opacity = '1'; }
    if (cursorTrail) { cursorTrail.style.width = '32px'; cursorTrail.style.height = '32px'; }
  });
});

/* ─── NAV SCROLL & ACTIVE ─── */
const nav = document.getElementById('nav');
const navLinks = document.querySelectorAll('.nav-link[href^="#"]');
const navToggle = document.getElementById('navToggle');
const navLinksEl = document.getElementById('navLinks');

window.addEventListener('scroll', () => {
  if (window.scrollY > 40) nav.classList.add('scrolled');
  else nav.classList.remove('scrolled');
  setActiveNavLink();
}, { passive: true });

navToggle.addEventListener('click', () => {
  navToggle.classList.toggle('open');
  navLinksEl.classList.toggle('open');
});

navLinksEl.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navToggle.classList.remove('open');
    navLinksEl.classList.remove('open');
  });
});

function setActiveNavLink() {
  const sections = document.querySelectorAll('section[id]');
  let current = '';
  sections.forEach(s => {
    if (window.scrollY >= s.offsetTop - 120) current = s.getAttribute('id');
  });
  navLinks.forEach(l => {
    l.classList.remove('active');
    if (l.getAttribute('href') === '#' + current) l.classList.add('active');
  });
}

/* ─── SCROLL REVEAL ─── */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const delay = el.dataset.revealDelay || 0;
      setTimeout(() => el.classList.add('revealed'), delay);
      revealObserver.unobserve(el);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('[data-reveal]').forEach((el, i) => {
  el.dataset.revealDelay = (i % 3) * 100;
  revealObserver.observe(el);
});

/* ─── SKILL BARS ─── */
const skillObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.querySelectorAll('.skill-fill').forEach(bar => {
        const w = bar.dataset.width || 0;
        setTimeout(() => { bar.style.width = w + '%'; }, 150);
      });
      skillObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.3 });

document.querySelectorAll('.skill-bars').forEach(el => skillObserver.observe(el));

/* ─── CONTACT FORM ─── */
const contactForm = document.getElementById('contactForm');
const formSuccess = document.getElementById('formSuccess');

if (contactForm) {
  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = contactForm.querySelector('button[type="submit"]');
    btn.textContent = 'Sending...';
    btn.disabled = true;
    setTimeout(() => {
      btn.textContent = 'Message Sent!';
      formSuccess.classList.add('visible');
      contactForm.reset();
      setTimeout(() => {
        btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Send Message`;
        btn.disabled = false;
        formSuccess.classList.remove('visible');
      }, 4000);
    }, 1200);
  });
}

/* ─── FOOTER YEAR ─── */
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

/* ─── SMOOTH SCROLL POLYFILL FOR BUTTONS ─── */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

/* ─── PARALLAX ON HERO GRID ─── */
const heroBg = document.querySelector('.hero-grid-bg');
window.addEventListener('scroll', () => {
  if (!heroBg) return;
  const y = window.scrollY;
  heroBg.style.transform = `translateY(${y * 0.3}px)`;
}, { passive: true });

/* ─── GLITCH EFFECT ON LOGO ─── */
const navLogo = document.querySelector('.nav-logo');
if (navLogo) {
  navLogo.addEventListener('mouseenter', function () {
    this.classList.add('glitch');
    setTimeout(() => this.classList.remove('glitch'), 400);
  });
}
